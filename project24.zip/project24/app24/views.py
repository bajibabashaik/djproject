from django.http import HttpResponse
from django.shortcuts import render
from .models import products


def readAll(request):
    all_products = products.objects.all()
    return render(request, "index.html", {"data":all_products})


def showindex(request):
    return readAll(request)


def savedata(request):
    p_no=request.POST.get("no")
    p_name=request.POST.get("name")
    p_price=request.POST.get("price")
    p_image=request.FILES.get("image")
    p1=products(no=p_no,name=p_name,price=p_price,image=p_image)
    p1.save()
    return readAll(request)


def deleteproduct(request):
    pno=request.GET.get("pno")
    products.objects.filter(no=pno).delete()
    return readAll(request)


def updatedetails(request):
    no=request.POST.get("no")
    res=products.objects.get(no=no)
    print(res)
    return render(request,"update.html",{"data":res})


def productdetails(request):
    p_no = request.POST.get("no")
    p_name = request.POST.get("name")
    p_price = request.POST.get("price")
    p_image = request.POST.get("image")
    p1 = products(no=p_no, name=p_name, price=p_price, image=p_image)
    p1.save()
    all_products = products.objects.all()
    print(all_products)
    return readAll(request)

