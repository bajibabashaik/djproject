from django.db import models

class products(models.Model):
    no=models.IntegerField(primary_key=True)
    name=models.CharField(max_length=40)
    price=models.DecimalField(max_digits=10,decimal_places=3)
    image=models.ImageField(upload_to='products/',default="default")
