from django.apps import AppConfig


class App24Config(AppConfig):
    name = 'app24'
